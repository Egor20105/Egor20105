# Welcome to My Hugo Site 
 
This is a test site created for educational purposes. 
 
## Pages: 
- [About](/about/) 
- [First Post](/posts/first-post/) 
