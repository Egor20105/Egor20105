# About Page

This is the about page for my Hugo site.

## Created for educational purposes
- Learning Hugo
- Static site generation
- Markdown content
